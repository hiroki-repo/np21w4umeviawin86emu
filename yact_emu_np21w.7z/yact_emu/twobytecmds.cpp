#include "stdafx.h"
#include "yact_emu.h"

static bool FASTCALL Cmd00(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd01(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd02(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd03(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd04(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd05(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd06(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd07(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd08(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd09(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd0A(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd0B(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd0C(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd0D(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd0E(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd0F(x86opcode *Op)
{
	return false;
}


static bool FASTCALL Cmd10(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd11(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd12(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd13(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd14(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd15(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd16(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd17(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd18(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd19(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd1A(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd1B(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd1C(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd1D(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd1E(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd1F(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd20(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd21(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd22(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd23(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd24(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd25(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd26(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd27(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd28(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd29(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd2A(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd2B(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd2C(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd2D(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd2E(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd2F(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd30(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd31(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd32(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd33(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd34(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd35(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd36(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd37(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd38(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd39(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd3A(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd3B(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd3C(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd3D(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd3E(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd3F(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd40(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd41(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd42(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd43(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd44(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd45(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd46(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd47(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd48(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd49(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd4A(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd4B(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd4C(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd4D(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd4E(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd4F(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd50(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd51(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd52(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd53(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd54(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd55(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd56(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd57(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd58(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd59(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd5A(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd5B(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd5C(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd5D(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd5E(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd5F(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd60(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd61(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd62(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd63(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd64(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd65(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd66(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd67(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd68(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd69(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd6A(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd6B(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd6C(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd6D(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd6E(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd6F(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd70(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd71(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd72(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd73(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd74(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd75(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd76(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd77(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd78(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd79(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd7A(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd7B(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd7C(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd7D(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd7E(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd7F(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd80(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd81(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd82(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd83(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd84(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd85(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd86(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd87(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd88(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd89(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd8A(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd8B(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd8C(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd8D(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd8E(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd8F(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd90(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd91(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd92(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd93(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd94(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd95(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd96(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd97(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd98(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd99(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd9A(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd9B(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd9C(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd9D(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd9E(x86opcode *Op)
{
	return false;
}

static bool FASTCALL Cmd9F(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdA0(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdA1(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdA2(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdA3(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdA4(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdA5(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdA6(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdA7(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdA8(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdA9(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdAA(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdAB(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdAC(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdAD(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdAE(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdAF(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdB0(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdB1(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdB2(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdB3(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdB4(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdB5(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdB6(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdB7(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdB8(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdB9(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdBA(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdBB(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdBC(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdBD(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdBE(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdBF(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdC0(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdC1(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdC2(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdC3(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdC4(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdC5(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdC6(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdC7(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdC8(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdC9(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdCA(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdCB(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdCC(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdCD(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdCE(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdCF(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdD0(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdD1(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdD2(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdD3(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdD4(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdD5(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdD6(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdD7(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdD8(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdD9(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdDA(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdDB(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdDC(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdDD(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdDE(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdDF(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdE0(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdE1(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdE2(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdE3(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdE4(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdE5(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdE6(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdE7(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdE8(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdE9(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdEA(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdEB(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdEC(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdED(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdEE(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdEF(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdF0(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdF1(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdF2(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdF3(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdF4(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdF5(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdF6(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdF7(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdF8(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdF9(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdFA(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdFB(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdFC(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdFD(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdFE(x86opcode *Op)
{
	return false;
}

static bool FASTCALL CmdFF(x86opcode *Op)
{
	return false;
}

COMMAND *TwoByteCmds[256]=
{
	Cmd00, Cmd01, Cmd02, Cmd03, Cmd04, Cmd05, Cmd06, Cmd07, Cmd08, Cmd09, Cmd0A, Cmd0B, Cmd0C, Cmd0D, Cmd0E, Cmd0F, 
	Cmd10, Cmd11, Cmd12, Cmd13, Cmd14, Cmd15, Cmd16, Cmd17, Cmd18, Cmd19, Cmd1A, Cmd1B, Cmd1C, Cmd1D, Cmd1E, Cmd1F, 
	Cmd20, Cmd21, Cmd22, Cmd23, Cmd24, Cmd25, Cmd26, Cmd27, Cmd28, Cmd29, Cmd2A, Cmd2B, Cmd2C, Cmd2D, Cmd2E, Cmd2F, 
	Cmd30, Cmd31, Cmd32, Cmd33, Cmd34, Cmd35, Cmd36, Cmd37, Cmd38, Cmd39, Cmd3A, Cmd3B, Cmd3C, Cmd3D, Cmd3E, Cmd3F, 
	Cmd40, Cmd41, Cmd42, Cmd43, Cmd44, Cmd45, Cmd46, Cmd47, Cmd48, Cmd49, Cmd4A, Cmd4B, Cmd4C, Cmd4D, Cmd4E, Cmd4F, 
	Cmd50, Cmd51, Cmd52, Cmd53, Cmd54, Cmd55, Cmd56, Cmd57, Cmd58, Cmd59, Cmd5A, Cmd5B, Cmd5C, Cmd5D, Cmd5E, Cmd5F, 
	Cmd60, Cmd61, Cmd62, Cmd63, Cmd64, Cmd65, Cmd66, Cmd67, Cmd68, Cmd69, Cmd6A, Cmd6B, Cmd6C, Cmd6D, Cmd6E, Cmd6F, 
	Cmd70, Cmd71, Cmd72, Cmd73, Cmd74, Cmd75, Cmd76, Cmd77, Cmd78, Cmd79, Cmd7A, Cmd7B, Cmd7C, Cmd7D, Cmd7E, Cmd7F, 
	Cmd80, Cmd81, Cmd82, Cmd83, Cmd84, Cmd85, Cmd86, Cmd87, Cmd88, Cmd89, Cmd8A, Cmd8B, Cmd8C, Cmd8D, Cmd8E, Cmd8F, 
	Cmd90, Cmd91, Cmd92, Cmd93, Cmd94, Cmd95, Cmd96, Cmd97, Cmd98, Cmd99, Cmd9A, Cmd9B, Cmd9C, Cmd9D, Cmd9E, Cmd9F, 
	CmdA0, CmdA1, CmdA2, CmdA3, CmdA4, CmdA5, CmdA6, CmdA7, CmdA8, CmdA9, CmdAA, CmdAB, CmdAC, CmdAD, CmdAE, CmdAF, 
	CmdB0, CmdB1, CmdB2, CmdB3, CmdB4, CmdB5, CmdB6, CmdB7, CmdB8, CmdB9, CmdBA, CmdBB, CmdBC, CmdBD, CmdBE, CmdBF, 
	CmdC0, CmdC1, CmdC2, CmdC3, CmdC4, CmdC5, CmdC6, CmdC7, CmdC8, CmdC9, CmdCA, CmdCB, CmdCC, CmdCD, CmdCE, CmdCF, 
	CmdD0, CmdD1, CmdD2, CmdD3, CmdD4, CmdD5, CmdD6, CmdD7, CmdD8, CmdD9, CmdDA, CmdDB, CmdDC, CmdDD, CmdDE, CmdDF, 
	CmdE0, CmdE1, CmdE2, CmdE3, CmdE4, CmdE5, CmdE6, CmdE7, CmdE8, CmdE9, CmdEA, CmdEB, CmdEC, CmdED, CmdEE, CmdEF, 
	CmdF0, CmdF1, CmdF2, CmdF3, CmdF4, CmdF5, CmdF6, CmdF7, CmdF8, CmdF9, CmdFA, CmdFB, CmdFC, CmdFD, CmdFE, CmdFF, 
};
